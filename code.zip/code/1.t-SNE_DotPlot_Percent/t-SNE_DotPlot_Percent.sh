Rscript do.R
