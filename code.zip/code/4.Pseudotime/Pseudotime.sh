Rscript RunMonocle2.R
Rscript DiffMonocle2.R
Rscript PlotMonocle2.R
