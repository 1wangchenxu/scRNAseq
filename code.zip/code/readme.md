Script:
1.t-SNE_DotPlot_Percent/t-SNE_DotPlot_Percent.sh : Draw t-SNE, marker gene bubble plot, and cell frequency plot
4.Pseudotime/Pseudotime.sh : Pseudotime flow analysis script
5.enrich/enrich.sh : Enrichment analysis script, including GO and KEGG
6.heatmap/heatmap.sh : Single-cell heatmap script
7.bar/bar.sh : Stacking diagram script
8.PCA/PCA.sh : PCA analysis and drawing script
9.GSEA/GSEA.sh : GSEA reference and data preprocessing, as well as analysis scripts
