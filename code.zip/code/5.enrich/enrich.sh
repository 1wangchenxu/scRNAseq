perl enrich.pl -i ./ -ref ref -summary 1
