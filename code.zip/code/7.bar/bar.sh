Rscirpt fill_bar.r
