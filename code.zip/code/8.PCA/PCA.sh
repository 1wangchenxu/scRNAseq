Rscript PCA.r
Rscript point.r
